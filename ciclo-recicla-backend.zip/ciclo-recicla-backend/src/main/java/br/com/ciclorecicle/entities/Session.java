package br.com.ciclorecicle.entities;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Session {

  private String name;

  private String token;
}
