package br.com.ciclorecicle.controllers;

import br.com.ciclorecicle.dtos.request.CreateUserRequestDTO;
import br.com.ciclorecicle.dtos.response.CreateUserResponseDTO;
import br.com.ciclorecicle.entities.Session;
import br.com.ciclorecicle.entities.User;
import br.com.ciclorecicle.services.CreateUserService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/users")
public class UsersController {

  @Autowired private ModelMapper modelMapper;

  @Autowired private CreateUserService createUserService;

  @PostMapping
  public ResponseEntity<CreateUserResponseDTO> createUser(
      @RequestBody CreateUserRequestDTO createUserRequestDTO) {

    User user = modelMapper.map(createUserRequestDTO, User.class);

    Session session = createUserService.execute(user);

    CreateUserResponseDTO createUserResponseDTO =
        modelMapper.map(session, CreateUserResponseDTO.class);

    return ResponseEntity.status(HttpStatus.CREATED).body(createUserResponseDTO);
  }
}
