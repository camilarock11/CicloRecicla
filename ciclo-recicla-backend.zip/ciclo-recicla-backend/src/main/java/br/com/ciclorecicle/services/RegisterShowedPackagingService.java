package br.com.ciclorecicle.services;

import br.com.ciclorecicle.entities.Packaging;
import br.com.ciclorecicle.entities.ShowedPackaging;
import br.com.ciclorecicle.repositories.ShowedPackagingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegisterShowedPackagingService {

  @Autowired private ShowedPackagingRepository showedPackagingRepository;

  public void execute(Packaging packaging) {
    showedPackagingRepository.save(ShowedPackaging.builder().packaging(packaging).build());
  }
}
