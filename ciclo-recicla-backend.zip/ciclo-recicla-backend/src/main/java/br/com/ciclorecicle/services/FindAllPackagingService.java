package br.com.ciclorecicle.services;

import br.com.ciclorecicle.entities.Packaging;
import br.com.ciclorecicle.repositories.PackagingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FindAllPackagingService {

  @Autowired private PackagingRepository packagingRepository;

  public List<Packaging> execute() {
    return packagingRepository.findAll();
  }
}
