package br.com.ciclorecicle.dtos.request;

import lombok.Data;

@Data
public class CreateSessionRequestDTO {

  private String document;

  private String password;
}
