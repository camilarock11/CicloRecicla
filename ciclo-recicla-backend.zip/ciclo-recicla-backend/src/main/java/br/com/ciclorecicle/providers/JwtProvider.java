package br.com.ciclorecicle.providers;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import org.springframework.stereotype.Component;

import java.util.Calendar;
import java.util.Date;

@Component
public class JwtProvider {

  private static final String SECRET = "SECRET";
  private static final String ISSUER = "ciclorecicla";

  public String generateToken(String sub) {
    Algorithm algorithm = Algorithm.HMAC256(SECRET);

    Date now = Calendar.getInstance().getTime();
    Date expiresAt = new Date(now.getTime() + 10 * 24 * 60 * 60 * 1000);

    return JWT.create()
        .withIssuer(ISSUER)
        .withExpiresAt(expiresAt)
        .withSubject(sub)
        .sign(algorithm);
  }

  public boolean validateToken(String token) {
    try {
      Algorithm algorithm = Algorithm.HMAC256(SECRET);

      JWTVerifier jwtVerifier = JWT.require(algorithm).withIssuer(ISSUER).build();

      jwtVerifier.verify(token);

      return true;
    } catch (JWTVerificationException exception) {

    }

    return false;
  }

  public String getSub(String token) {
    DecodedJWT jwt = JWT.decode(token);

    return jwt.getSubject();
  }
}
