package br.com.ciclorecicle.dtos.request;

import lombok.Data;

@Data
public class CreateUserRequestDTO {

  private String name;

  private String document;

  private String email;

  private String password;

  private String role;
}
