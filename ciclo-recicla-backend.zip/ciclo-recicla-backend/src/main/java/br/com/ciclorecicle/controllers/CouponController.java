package br.com.ciclorecicle.controllers;

import br.com.ciclorecicle.entities.Coupon;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/coupon")
public class CouponController {

  @GetMapping
  public ResponseEntity<List<Coupon>> getCoupons() {
    return ResponseEntity.ok(
        Arrays.asList(
            Coupon.builder()
                .name("10% OFF no Mercado X")
                .marketplaceName("Mercado X")
                .rescueDate("06/2022")
                .score("200 estrelas")
                .build(),
            Coupon.builder()
                .name("20% OFF no Mercado X")
                .marketplaceName("Mercado X")
                .rescueDate("07/2022")
                .score("800 estrelas")
                .build(),
            Coupon.builder()
                .name("5% OFF no Mercado X")
                .marketplaceName("Mercado X")
                .rescueDate("07/2022")
                .score("150 estrelas")
                .build()));
  }
}
