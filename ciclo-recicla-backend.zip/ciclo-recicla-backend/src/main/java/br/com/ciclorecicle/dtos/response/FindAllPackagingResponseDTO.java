package br.com.ciclorecicle.dtos.response;

import br.com.ciclorecicle.dtos.DisposalInstructions;
import com.fasterxml.jackson.annotation.JsonUnwrapped;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class FindAllPackagingResponseDTO {

  @JsonUnwrapped List<Packaging> packaging;

  @Data
  public static final class Packaging {

    private String image;

    private String name;

    private String type;

    private List<DisposalInstructions> disposalInstructions;

    private String qrCode;
  }
}
