package br.com.ciclorecicle.controllers;

import br.com.ciclorecicle.dtos.response.CreateSessionResponseDTO;
import br.com.ciclorecicle.dtos.request.CreateSessionRequestDTO;
import br.com.ciclorecicle.entities.Session;
import br.com.ciclorecicle.services.CreateSessionService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/sessions")
public class SessionsController {

  @Autowired private CreateSessionService createSessionService;

  @Autowired private ModelMapper modelMapper;

  @PostMapping
  public CreateSessionResponseDTO createSession(
      @RequestBody CreateSessionRequestDTO createSessionRequestDTO) throws Exception {

    Session session =
        createSessionService.execute(
            createSessionRequestDTO.getDocument(), createSessionRequestDTO.getPassword());

    return modelMapper.map(session, CreateSessionResponseDTO.class);
  }
}
