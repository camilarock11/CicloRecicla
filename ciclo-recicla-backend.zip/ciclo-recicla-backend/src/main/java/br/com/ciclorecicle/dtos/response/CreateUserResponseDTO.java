package br.com.ciclorecicle.dtos.response;

import lombok.Data;

@Data
public class CreateUserResponseDTO {

  private String name;

  private String token;
}
