package br.com.ciclorecicle.controllers;

import br.com.ciclorecicle.dtos.response.GetScoreResponseDTO;
import br.com.ciclorecicle.entities.Score;
import br.com.ciclorecicle.services.GetScoreService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/score")
public class ScoreController {

  @Autowired private GetScoreService getScoreService;

  @Autowired private ModelMapper modelMapper;

  @GetMapping
  public ResponseEntity<GetScoreResponseDTO> getScore() {
    Score score = getScoreService.execute();

    return ResponseEntity.ok(modelMapper.map(score, GetScoreResponseDTO.class));
  }
}
