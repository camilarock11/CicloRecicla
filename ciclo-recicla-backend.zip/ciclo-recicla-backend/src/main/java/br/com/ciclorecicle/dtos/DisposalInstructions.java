package br.com.ciclorecicle.dtos;

import lombok.Data;

@Data
public class DisposalInstructions {

  private String icon;

  private String instruction;
}
