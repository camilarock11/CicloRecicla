package br.com.ciclorecicle.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Arrays;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Score {

  private Integer totalScore;

  private List<Packaging> packaging;

  private List<Coupon> coupons;

  private List<Coupon> rescuedCoupons;
}
