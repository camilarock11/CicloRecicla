package br.com.ciclorecicle.providers;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

@Component
public class QrCodeProvider {

  private static final String FORMAT = "PNG";
  private static final String URL = "http://192.168.15.141:3001/produto/%s";
  private static final String QRCODE_URL = "http://192.168.15.100:8080/static/%s";

  public String create(String data) {
    try {
      BitMatrix bitMatrix =
          new MultiFormatWriter()
              .encode(String.format(URL, data), BarcodeFormat.QR_CODE, 1024, 1024);

      Path path =
          Paths.get("")
              .toAbsolutePath()
              .resolve("src")
              .resolve("main")
              .resolve("public")
              .resolve("qrcode_" + data + ".png");

      MatrixToImageWriter.writeToPath(bitMatrix, FORMAT, path);

      return String.format(QRCODE_URL, "qrcode_" + data + ".png");

    } catch (WriterException | IOException e) {
      throw new RuntimeException(e);
    }
  }
}
