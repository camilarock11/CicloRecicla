package br.com.ciclorecicle.dtos.response;

import lombok.Data;

import java.util.List;

@Data
public class GetScoreResponseDTO {

  private Integer totalScore;

  private List<Packaging> packaging;

  private List<Coupon> coupons;

  private List<Coupon> rescuedCoupons;

  @Data
  public static final class Packaging {

    private String name;

    private String image;

    private String type;
  }

  @Data
  private static final class Coupon {

    private String name;

    private String image;

    private String marketplaceName;

    private String rescueDate;

    private String score;
  }
}
