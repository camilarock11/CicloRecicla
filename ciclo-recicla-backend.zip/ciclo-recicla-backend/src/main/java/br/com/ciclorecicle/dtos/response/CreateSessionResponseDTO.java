package br.com.ciclorecicle.dtos.response;

import lombok.Data;

@Data
public class CreateSessionResponseDTO {

  private String name;

  private String token;
}
