package br.com.ciclorecicle.dtos.response;

import br.com.ciclorecicle.dtos.DisposalInstructions;
import lombok.Data;

import java.util.List;

@Data
public class CreatePackagingResponseDTO {

  private String id;

  private String name;

  private String image;

  private String type;

  private List<DisposalInstructions> disposalInstructions;

  private String qrCode;
}
