package br.com.ciclorecicle.services;

import br.com.ciclorecicle.repositories.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

  @Autowired UsersRepository usersRepository;

  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    return usersRepository
        .findByDocument(username)
        .map(
            user ->
                new org.springframework.security.core.userdetails.User(
                    user.getId(),
                    user.getPassword(),
                    Collections.singletonList(
                        new GrantedAuthority() {
                          @Override
                          public String getAuthority() {
                            return user.getRole();
                          }
                        })))
        .orElseThrow(() -> new UsernameNotFoundException("Bad credentials"));
  }
}
