package br.com.ciclorecicle.controllers;

import br.com.ciclorecicle.dtos.request.CreatePackagingRequestDTO;
import br.com.ciclorecicle.dtos.response.CreatePackagingResponseDTO;
import br.com.ciclorecicle.dtos.response.FindAllPackagingResponseDTO;
import br.com.ciclorecicle.dtos.response.FindPackagingResponseDTO;
import br.com.ciclorecicle.entities.Packaging;
import br.com.ciclorecicle.services.CreatePackagingService;
import br.com.ciclorecicle.services.FindAllPackagingService;
import br.com.ciclorecicle.services.FindPackagingService;
import br.com.ciclorecicle.services.RegisterShowedPackagingService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/packaging")
public class PackagingController {

  @Autowired private CreatePackagingService createPackagingService;

  @Autowired private FindPackagingService findPackagingService;

  @Autowired private FindAllPackagingService findAllPackagingService;

  @Autowired private RegisterShowedPackagingService registerShowedPackagingService;

  @Autowired private ModelMapper modelMapper;

  @PostMapping
  public ResponseEntity<CreatePackagingResponseDTO> createPackaging(
      @RequestBody CreatePackagingRequestDTO createPackagingRequestDTO) {

    Packaging packaging = modelMapper.map(createPackagingRequestDTO, Packaging.class);

    packaging = createPackagingService.execute(packaging);

    CreatePackagingResponseDTO createPackagingResponseDTO =
        modelMapper.map(packaging, CreatePackagingResponseDTO.class);

    return ResponseEntity.status(HttpStatus.CREATED).body(createPackagingResponseDTO);
  }

  @GetMapping("/{id}")
  public ResponseEntity<FindPackagingResponseDTO> getPackaging(@PathVariable String id) {
    Packaging packaging = findPackagingService.execute(id);

    FindPackagingResponseDTO findPackagingResponseDTO =
        modelMapper.map(packaging, FindPackagingResponseDTO.class);

    if (SecurityContextHolder.getContext().getAuthentication().getPrincipal() != null) {
      registerShowedPackagingService.execute(packaging);
    }

    return ResponseEntity.ok(findPackagingResponseDTO);
  }

  @GetMapping
  public ResponseEntity<FindAllPackagingResponseDTO> getAllPackaging() {
    List<Packaging> allPackaging = findAllPackagingService.execute();

    return ResponseEntity.ok(
        FindAllPackagingResponseDTO.builder()
            .packaging(
                allPackaging.stream()
                    .map(
                        packaging ->
                            modelMapper.map(packaging, FindAllPackagingResponseDTO.Packaging.class))
                    .toList())
            .build());
  }
}
