package br.com.ciclorecicle.dtos.request;

import br.com.ciclorecicle.dtos.DisposalInstructions;
import lombok.Data;

import java.util.List;

@Data
public class CreatePackagingRequestDTO {

  private String name;

  private String image;

  private String type;

  private List<DisposalInstructions> disposalInstructions;
}
