package br.com.ciclorecicle.services;

import br.com.ciclorecicle.entities.Coupon;
import br.com.ciclorecicle.entities.Score;
import br.com.ciclorecicle.entities.ShowedPackaging;
import br.com.ciclorecicle.repositories.ShowedPackagingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class GetScoreService {

  private static final Integer INITIAL_RANGE = 10;
  private static final Integer FINAL_RANGE = 15;

  @Autowired private ShowedPackagingRepository showedPackagingRepository;

  public Score execute() {
    List<ShowedPackaging> showedPackaging = showedPackagingRepository.findAll();

    int totalScore = 0;

    for (int i = 0; i < showedPackaging.size(); i++) {
      totalScore += (int) (Math.random() * (FINAL_RANGE - INITIAL_RANGE)) + INITIAL_RANGE;
    }

    return Score.builder()
        .totalScore(totalScore)
        .packaging(showedPackaging.stream().map(ShowedPackaging::getPackaging).toList())
        .coupons(
            Arrays.asList(
                Coupon.builder()
                    .name("10% OFF no Mercado X")
                    .marketplaceName("Mercado X")
                    .rescueDate("06/2022")
                    .score("200 estrelas")
                    .build(),
                Coupon.builder()
                    .name("16% OFF no Mercado Y")
                    .marketplaceName("Mercado Y")
                    .rescueDate("07/2022")
                    .score("350 estrelas")
                    .build(),
                Coupon.builder()
                    .name("5% OFF no Mercado Z")
                    .marketplaceName("Mercado Z")
                    .rescueDate("07/2022")
                    .score("100 estrelas")
                    .build()))
        .rescuedCoupons(
            Arrays.asList(
                Coupon.builder()
                    .name("18% OFF no Mercado X")
                    .marketplaceName("Mercado X")
                    .rescueDate("05/2022")
                    .score("- 400 estrelas")
                    .build(),
                Coupon.builder()
                    .name("7,5% OFF no Mercado Y")
                    .marketplaceName("Mercado Y")
                    .rescueDate("05/2022")
                    .score("- 175 estrelas")
                    .build(),
                Coupon.builder()
                    .name("12,5% OFF no Mercado Z")
                    .marketplaceName("Mercado Z")
                    .rescueDate("05/2022")
                    .score("- 225 estrelas")
                    .build()))
        .build();
  }
}
