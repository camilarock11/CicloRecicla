package br.com.ciclorecicle.services;

import br.com.ciclorecicle.entities.Session;
import br.com.ciclorecicle.entities.User;
import br.com.ciclorecicle.exception.ApplicationException;
import br.com.ciclorecicle.repositories.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class CreateUserService {

  private static final String ROLE_CORPORATE = "ROLE_CORPORATE";
  private static final String ROLE_USER = "ROLE_USER";

  @Autowired private PasswordEncoder passwordEncoder;

  @Autowired private UsersRepository usersRepository;

  @Autowired private CreateSessionService createSessionService;

  public Session execute(User user) {
    String plainPassword = user.getPassword();

    if (usersRepository.findByDocument(user.getDocument()).isPresent()) {
      throw new ApplicationException("Document already used");
    }

    user.setId(UUID.randomUUID().toString());
    user.setPassword(passwordEncoder.encode(user.getPassword()));

    if (user.getDocument().length() == 11) {
      user.setRole(ROLE_USER);
    } else if (user.getDocument().length() == 14) {
      user.setRole(ROLE_CORPORATE);
    } else {
      throw new ApplicationException("Invalid document");
    }

    usersRepository.save(user);

    return createSessionService.execute(user.getDocument(), plainPassword);
  }
}
