package br.com.ciclorecicle.services;

import br.com.ciclorecicle.entities.Packaging;
import br.com.ciclorecicle.repositories.PackagingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FindPackagingService {

  @Autowired private PackagingRepository packagingRepository;

  public Packaging execute(String id) {
    return packagingRepository.findById(id).orElseThrow(() -> new RuntimeException("Not Found"));
  }
}
