package br.com.ciclorecicle.entities;

import lombok.Data;

import javax.persistence.*;
import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Data
@Entity
public class Packaging implements Serializable {

  @Serial private static final long serialVersionUID = 1L;

  @Id private String id;

  private String name;

  @Lob private String image;

  private String type;

  @OneToMany(cascade = CascadeType.ALL)
  @JoinColumn(name = "packaging_id")
  private List<DisposalInstructions> disposalInstructions;

  @Lob private String qrCode;
}
