package br.com.ciclorecicle.services;

import br.com.ciclorecicle.entities.Session;
import br.com.ciclorecicle.exception.ApplicationException;
import br.com.ciclorecicle.providers.JwtProvider;
import br.com.ciclorecicle.repositories.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;

@Service
public class CreateSessionService {

  @Autowired AuthenticationManager authenticationManager;

  @Autowired JwtProvider jwtProvider;

  @Autowired UsersRepository usersRepository;

  public Session execute(String document, String password) {

    try {
      authenticationManager.authenticate(
          new UsernamePasswordAuthenticationToken(document, password));
    } catch (BadCredentialsException e) {
      throw new ApplicationException("Bad credentials");
    }

    String token = jwtProvider.generateToken(document);

    return usersRepository
        .findByDocument(document)
        .map(user -> Session.builder().name(user.getName()).token(token).build())
        .orElseThrow(() -> new ApplicationException("Bad credentials"));
  }
}
