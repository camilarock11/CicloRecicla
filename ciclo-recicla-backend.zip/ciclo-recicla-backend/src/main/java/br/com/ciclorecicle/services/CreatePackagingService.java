package br.com.ciclorecicle.services;

import br.com.ciclorecicle.entities.Packaging;
import br.com.ciclorecicle.providers.QrCodeProvider;
import br.com.ciclorecicle.repositories.PackagingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.UUID;

@Service
public class CreatePackagingService {

  private static final String IMAGE_URL = "http://192.168.15.100:8080/static/%s";

  @Autowired private QrCodeProvider qrCodeProvider;

  @Autowired private PackagingRepository packagingRepository;

  public Packaging execute(Packaging packaging) {
    String uuid = UUID.randomUUID().toString();

    String imageFormat = packaging.getImage().split(";")[0].split("/")[1];
    var decodedImage = Base64.getDecoder().decode(packaging.getImage().split(",")[1]);

    try {
      FileOutputStream fileOutputStream =
          new FileOutputStream("src/main/public/image_" + uuid + "." + imageFormat);

      fileOutputStream.write(decodedImage);

      packaging.setId(uuid);
      packaging.setQrCode(qrCodeProvider.create(uuid));
      packaging.setImage(String.format(IMAGE_URL, "image_" + uuid + "." + imageFormat));

      return packagingRepository.save(packaging);
    } catch (FileNotFoundException e) {
      throw new RuntimeException(e);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }
}
